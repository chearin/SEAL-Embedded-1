#pragma once

#include "defines.h"

#if defined(SE_DATA_FROM_CODE_COPY) || defined(SE_DATA_FROM_CODE_DIRECT)

#include <stdint.h>

#ifdef SE_NTT_REG
   #include "str_ntt_roots_1024_134012929.h"
#elif defined(SE_NTT_FAST)
   #include "str_ntt_fast_roots_1024_134012929.h"
#endif

ZZ* ntt_roots_addr[1] =
{
  &(((ZZ*)(ntt_roots_save_prime0))[0])
};

#endif
