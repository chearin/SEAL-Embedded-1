#pragma once

#include "defines.h"

#if defined(SE_DATA_FROM_CODE_COPY) || defined(SE_DATA_FROM_CODE_DIRECT)

#include <stdint.h>

#ifdef SE_INTT_REG
   #include "str_intt_roots_1024_134012929.h"
#elif defined(SE_INTT_FAST)
   #include "str_intt_fast_roots_1024_134012929.h"
#endif

ZZ* intt_roots_addr[1] =
{
  &(((ZZ*)(intt_roots_save_prime0))[0])
};

#endif
