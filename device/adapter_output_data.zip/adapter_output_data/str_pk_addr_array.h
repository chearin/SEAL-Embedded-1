#pragma once

#include "defines.h"

#if defined(SE_DATA_FROM_CODE_COPY) || defined(SE_DATA_FROM_CODE_DIRECT)

   #include "str_pk0_ntt_1024_134012929.h"
   #include "str_pk1_ntt_1024_134012929.h"

ZZ* pk_prime_addr[1][2] = 
{
    {&(pk0_prime0[0]), &(pk1_prime0[0])}
};
#endif
